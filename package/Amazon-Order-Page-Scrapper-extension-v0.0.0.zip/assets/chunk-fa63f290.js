console.info("chrome-ext template-react-ts background script");
